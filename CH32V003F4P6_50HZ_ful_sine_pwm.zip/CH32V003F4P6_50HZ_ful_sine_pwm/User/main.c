/////////////////////////
// 50Hz PWM TEST      ///
// 2024-7  myoko      ///
/////////////////////////
//
#include "debug.h"
#include "sindat.h"
//
//#define half_sine_50HZ
//#define half_sine_60HZ
//#define full_sine_50HZ
#define full_sine_60HZ
//
//port setting  PD4 Ch1 PD3 ch2  PC3 CH3 //pwm out
//              PC2 interrupt out

//Timer2 pin mappings[AFIO->PCFR1]
// 00 (default)  01              10              11
// PD4 T2CH1ETR  PC5 T2CH1ETR_   PC1 T2CH1ETR_   PC1 T2CH1ETR_
// PD3 T2CH2     PC2 T2CH2_      PD3 T2CH2       PC7 T2CH2_
// PC0 T2CH3     PD2 T2CH3_      PC0 T2CH3       PD6 T2CH3_
// PD7 T2CH4     PC1 T2CH4_      PD7 T2CH4       PD5 T2CH4_


//variable
uint8_t n;
uint8_t channel=0;
void TIM2_PWM_INIT( uint16_t  period,uint16_t prescall,uint16_t with){
  GPIO_InitTypeDef GPIO_InitStructure={0};
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC , ENABLE );
     GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
     GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
     GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
     GPIO_Init( GPIOC, &GPIO_InitStructure );
     GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
     GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
     GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
     GPIO_Init( GPIOC, &GPIO_InitStructure );
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOD , ENABLE );
     GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 ;
     GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
     GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
     GPIO_Init( GPIOD, &GPIO_InitStructure );
 TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure={0};
 RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM2, ENABLE );
     TIM_TimeBaseInitStructure.TIM_Period = period;
     TIM_TimeBaseInitStructure.TIM_Prescaler = prescall;
     TIM_TimeBaseInitStructure.TIM_ClockDivision = 0;
     TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
     TIM_TimeBaseInit( TIM2, &TIM_TimeBaseInitStructure);
 TIM_OCInitTypeDef TIM_OCInitStructure={0};
     TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Disable;
     TIM_OC3Init(TIM2,&TIM_OCInitStructure);//ch4 disable
     TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
     TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
     TIM_OCInitStructure.TIM_Pulse = with;
     TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
     TIM_OC1Init(TIM2,&TIM_OCInitStructure );
     TIM_OC2Init(TIM2,&TIM_OCInitStructure);
     TIM_OC3Init(TIM2,&TIM_OCInitStructure);
     TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);//for interrupt
     TIM_Cmd( TIM2, ENABLE );
}
void Interrupt_Init(void){
   NVIC_InitTypeDef NVIC_InitStructure={0};
   NVIC_InitStructure.NVIC_IRQChannel =TIM2_IRQn;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);
}
void TIM2_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void TIM2_IRQHandler(void){
#if defined(half_sine_50HZ) || defined(half_sine_60HZ)
    if(n>=200){n=0;channel=~channel;}
    if(channel==0){TIM_SetCompare1(TIM2,sindat1[n]);n++;}
    else{TIM_SetCompare2(TIM2,sindat1[n]);n++;}
#elif defined(full_sine_50HZ) || defined(full_sine_60HZ)
    if(n>=200){n=0;}
    TIM_SetCompare1(TIM2,full_sin[n]);
    TIM_SetCompare2(TIM2,full_sin[n]);n++;
#endif
    GPIO_SetBits(GPIOC, GPIO_Pin_1);GPIO_ResetBits(GPIOC, GPIO_Pin_1);//for interrupt debug
    TIM_ClearFlag(TIM2, TIM_FLAG_Update);//int flug reset
 }
int main(){
    SystemInit();
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);//int prio
    Delay_Ms( 100 );
    USART_Printf_Init(115200);
    printf("\r\n TIMER2 FULL_PWM TEST \n\r");
    Interrupt_Init();
    n=0;
#ifdef half_sine_50HZ
    TIM2_PWM_INIT(200-1,12-1,2);//duty1%
#elif  defined(half_sine_60HZ)
    TIM2_PWM_INIT(200-1,10-1,2);//duty1%
#elif  defined(full_sine_50HZ)
    TIM2_PWM_INIT(200-1,24-1,2);//duty1%
#elif  defined(full_sine_60HZ)
    TIM2_PWM_INIT(200-1,20-1,2);//duty1%
#endif

    while(1){
     }
}
